// Welcome to window's source
// Written by Bill Gates himself
// All the other Microsoft engineers are just for show

// Use GNU/Linux instead Bill!
//     - Love, Stallman.

#include <stdio.h>

int main(void){

    printf("No matter how many copies of Windows you have bought so far it isn't enough to activate this instillation. Please buy some more to proceed.\n");
    printf("swampCTF{It5_GNU_PLU5_1InuX_BI11}");
    
    return 0;
}
