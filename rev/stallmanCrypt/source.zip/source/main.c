#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <time.h>

#include "chacha.h"
#include "hex.h"

#define NUMROUNDS 20 //TODO make a product of the output rand maybe? Or change so that it isn't the spec

void printHelp(){

    printf( "Usage: stallmanCrypt [OPTIONS]...\n"\
            "Encrypts/Decrypts files using stallmanCrypt\n"
            "\n"\
            " -h                        Prints this screen\n"\
            " -e [filename]             Encrypts a specified file (must be passed with -r)\n"\
            " -d [filename]             Decrypts a specified file (must be passed with -k)\n"\
            " -k [512 bit Key in hex]   Specifies the key used for decryption\n"\
            " -r                        Generates a random key\n"\
            "\n"\
            "Examples - \n"\
            "stallmanCrypt -r -e testfile.txt\n"\
            "stallmanCrypt -d testfile.txt.enc -k 6e6f2074686973206973206e6f742074686520666c616720627574206e69636520747279206c6d616f212120476574206f757474612068657265212121203a50\n"\
            "\n");

    exit(0);
}

void fileEncrypt(char filename[], uint32_t userProvidedState[]){

    uint32_t counter = 1;
    uint32_t plainBufferLen = 1;
    chachastate chaInfo;

    size_t readSize = 65536;
    uint8_t buffer[readSize];

    char *fixedName = malloc(strlen(filename) * sizeof(char) + 7);
    fixedName[0] = '.';
    fixedName[1] = '/';
    fixedName[2] = '\0';
    strcat(fixedName, filename);

    FILE *rfp;
    rfp = fopen(fixedName,"rb");

    if(rfp == NULL){
        printf("Could not open %s\nQuitting...\n", filename);
        exit(1);
    }

    strcat(fixedName, ".enc");

    FILE *wfp;
    wfp = fopen(fixedName,"wb");


    if(wfp == NULL){
        printf("Could not create encrypted file %s\nQuitting...\n", fixedName);
        exit(1);
    }

    ChaChaInitialize(&chaInfo, userProvidedState, &counter, NUMROUNDS);

    // While there is data still to be read from the file encrypt it
    while(plainBufferLen != 0){
        plainBufferLen = fread(buffer, 1, readSize, rfp);

        ChaChaEncrypt(&chaInfo, plainBufferLen, buffer);

        fwrite(buffer, 1, plainBufferLen, wfp);
    }

    fclose(rfp);
    fclose(wfp);
    free(fixedName);

    printf("The file has been encrypted and written to %s\n", strcat(filename, ".enc"));
}

void fileDecrypt(char filename[], uint8_t userProvidedState[]){
    uint32_t counter = 1;
    uint32_t plainBufferLen = 1;
    chachastate chaInfo;

    size_t readSize = 65536;
    uint8_t buffer[readSize];

    char *fixedName = malloc(strlen(filename) * sizeof(char) + 5);
    fixedName[0] = '.';
    fixedName[1] = '/';
    fixedName[2] = '\0';
    strcat(fixedName, filename);

    FILE *rfp;
    rfp = fopen(fixedName,"rb");

    if(rfp == NULL){
        printf("Could not open %s\nQuitting...\n", filename);
        exit(1);
    }

    fixedName[strlen(fixedName) - 4] = '\0';

    FILE *wfp;
    wfp = fopen(fixedName,"wb");

    if(wfp == NULL){
        printf("Could not create encrypted file %s\nQuitting...\n", strcat(fixedName, ".enc"));
        exit(1);
    }

    ChaChaInitialize(&chaInfo, (uint32_t*)userProvidedState, &counter, NUMROUNDS);

    // While there is data still to be read from the file encrypt it
    while(plainBufferLen != 0){
        plainBufferLen = fread(buffer, 1, readSize, rfp);

        // Encryption and decryption are the same operation for stream ciphers
        ChaChaEncrypt(&chaInfo, plainBufferLen, buffer);

        fwrite(buffer, 1, plainBufferLen, wfp);
    }

    fclose(rfp);
    fclose(wfp);
    free(fixedName);

    filename[strlen(filename) - 4] = '\0';
    printf("The file has been decrypted and written to %s\n", filename);
}

int main(int argc, char *argv[]) {

    int opt;
    //char nonceStr[25] = {'\0'};
    char keyStr[256] = {'\0'};
    char fileStr[256] = {'\0'};
    uint8_t encFlag = 0;
    uint8_t decFlag = 0;
    uint8_t randomFlag = 0;

    uint8_t keyFlag = 0;
    uint8_t nonceFlag = 0;

    uint32_t userProvidedState[16];

    // put ':' in the starting of the
    // string so that program can
    //distinguish between '?' and ':'
    while((opt = getopt(argc, argv, ":d:e:rk:h")) != -1)
    {
        switch(opt)
        {
            case 'd':
                decFlag = 1;
                strcpy(fileStr, optarg);
                break;
            case 'e':
                encFlag = 1;
                strncpy(fileStr, optarg, 255);
                break;
            case 'r':
                randomFlag = 1;
                break;
            case 'k':
                keyFlag = 1;
                nonceFlag = 1;
                strncpy(keyStr, optarg, 256);
                break;
            //case 'n':
                //nonceFlag = 1;
                //strncpy(nonceStr, optarg, 24);
                //break;
            case 'h':
                printHelp();
                //break;
            case ':':
                printf("option needs a value\n");
                break;
            case '?':
                printf("unknown option: %c\n", optopt);
                break;
        }
    }

    // Check to see if -r and -k are passed together or not at all
    if((randomFlag != 1 && (keyFlag != 1 || nonceFlag != 1)) || (randomFlag == 1 && (keyFlag == 1 || nonceFlag == 1))){
        printHelp();
    }

    // Check to see if -d and -e are passed together or not at all
    if((encFlag == 1 && decFlag == 1) || (encFlag != 1 && decFlag != 1)){
        printHelp();
    }

    if(encFlag == 1){
        if(randomFlag == 1){

            time_t seconds;
            seconds = time(NULL);
            time_t *rngSeedPtr = &seconds;

            srand(*rngSeedPtr);

            for(int i = 0; i < 16; i++){
                userProvidedState[i] = rand();
            }

            printf("Random key: %s\n", binToHex((uint8_t*)userProvidedState, 64));
            printf("Keep this key safe. It is needed to decrypt the file.\n");


            fileEncrypt(fileStr, userProvidedState);
        } else {

            printHelp();

        }
    }


    if(decFlag == 1){
        // Same trick I used in the encryption key display is used here as well
        printf("Key: %s\n", binToHex(hexToBin(keyStr, 128), 64));

        fileDecrypt(fileStr, hexToBin(keyStr, 128));
    }
}
